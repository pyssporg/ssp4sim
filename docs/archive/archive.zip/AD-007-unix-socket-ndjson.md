---
id: AD-007
title: Unix Domain Socket with Newline-Delimited JSON for the Local Control Daemon
summary: The control daemon is a local frontend that exchanges newline-delimited JSON over an AF_UNIX socket; the engine keeps no network listener.
date: 2026-11-25
status: accepted
layers: [architecture, implementation]
state: 03-implementation/interfaces.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
  - docs/build_from_source.md
supersedes: []
superseded_by: []
related: [REQ-016]
---

# AD-007: Unix Domain Socket with Newline-Delimited JSON for the Local Control Daemon

## Context

The engine needs a way for local tools to drive a running simulation without
adding a network service to the core. Control clients need lifecycle commands,
speed and override updates, variable discovery, state snapshots, and progress
events. The transport should match the Linux-first, single-node scope and stay
small enough to implement with the standard library plus the existing JSON
dependency.

## Decision

`ssp4simd` is a separate executable that listens on an `AF_UNIX` stream socket
and exchanges newline-delimited JSON with protocol version `"v":1`. Requests
carry a `cmd` and an optional `id`; responses echo the `id`; unsolicited events
carry no `id`. The engine library itself opens no listening socket.

## Rationale

A Unix domain socket keeps access on the local filesystem, supports file
permissions (`0600`), and avoids port allocation and remote exposure. NDJSON is
trivial to frame, debug, and implement in C++, Python, or shell clients, and
reuses the repository's existing JSON library. A version field and request ids
leave room for protocol evolution and for matching responses to requests on one
persistent connection.

## Alternatives Considered

- A TCP listener with a custom binary framing.
- Embedding the daemon loop in `sim_app` behind a flag.
- One-shot command files or signals instead of a persistent connection.

## Consequences

- Positive: local-only access with filesystem permissions; no engine network listener; simple clients and a testable protocol.
- Negative: a second process owns the socket and one active simulation; slow clients can lose droppable `time` events; clients must implement newline framing.

## Verification

`src/public/ssp4sim_server/test_ndjson.cpp` covers framing and protocol parsing;
`tests/python/test_ssp4simd.py` exercises a live daemon over the socket,
including `reset` and `shutdown`.

## Review Trigger

Revisit if control must cross host boundaries or if a standard protocol replaces
the local NDJSON contract.
